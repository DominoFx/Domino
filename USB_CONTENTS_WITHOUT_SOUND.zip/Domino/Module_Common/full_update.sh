git pull
sudo rm -r dist/
sudo rm -r build/
make all
