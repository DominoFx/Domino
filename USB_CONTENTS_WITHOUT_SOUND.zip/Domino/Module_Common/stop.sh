sudo killall domino
sudo killall sclang
sudo killall scsynth